#!/bin/bash

cd /storage/roms/ports/M8

#./alsaloop -P hw:rk817ext,0 -C hw:M8,0 -t 200000 -A 5 --rate 44100 --sync=0 -T -1 -d
./alsaloop -P sysdefault:CARD=rk817ext -C sysdefault:CARD=M8 -t 200000 -A 5 --rate 44100 --sync=0 -T -1 -d
sleep 2
./_m8c/m8c

pkill alsaloop
